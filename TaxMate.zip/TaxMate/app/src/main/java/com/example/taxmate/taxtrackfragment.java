
package com.example.taxmate;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class taxtrackfragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public taxtrackfragment() {
        // Required empty public constructor
    }

    public static taxtrackfragment newInstance(String param1, String param2) {
        taxtrackfragment fragment = new taxtrackfragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.taxtrackfragment, container, false);
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Button calculateButton = view.findViewById(R.id.calculate_button);
        EditText ageText = view.findViewById(R.id.age_edit_text);
        EditText salarytext = view.findViewById(R.id.salary_edit_text);
        EditText hratext = view.findViewById(R.id.hra);
        EditText ltatext = view.findViewById(R.id.lta);
        EditText savingsDepositInteresttext = view.findViewById(R.id.savings);
        EditText otherAllowancestext = view.findViewById(R.id.other_edit_text);
        EditText sec80text = view.findViewById(R.id.sec80c_edit_text);
        EditText medInsurancetext = view.findViewById(R.id.medic_edit_text);
        EditText eduLoanInteresttext = view.findViewById(R.id.edloan_edit_text);
        EditText homeLoanInteresttext = view.findViewById(R.id.houseloan_edit_text);
        EditText evLoanInteresttext = view.findViewById(R.id.evloan_edit_text);
        EditText charityDonationstext = view.findViewById(R.id.donation_edit_text);
        EditText npsContributionstext = view.findViewById(R.id.nps);
        EditText otherDeductionstext = view.findViewById(R.id.otherdeduct_edit_text);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "Calculation Successful!", Toast.LENGTH_SHORT).show();

                int age = Integer.parseInt(ageText.getText().toString());
                int salary = Integer.parseInt(salarytext.getText().toString());
                int hra = Integer.parseInt(hratext.getText().toString());
                int lta = Integer.parseInt(ltatext.getText().toString());
                int savingsDepositInterest = Integer.parseInt(savingsDepositInteresttext.getText().toString());
                int otherAllowances = Integer.parseInt(otherAllowancestext.getText().toString());
                int sec80c = Integer.parseInt(sec80text.getText().toString());
                int medInsurance = Integer.parseInt(medInsurancetext.getText().toString());
                int eduLoanInterest = Integer.parseInt(eduLoanInteresttext.getText().toString());
                int homeLoanInterest = Integer.parseInt(homeLoanInteresttext.getText().toString());
                int evLoanInterest = Integer.parseInt(evLoanInteresttext.getText().toString());
                int charityDonations = Integer.parseInt(charityDonationstext.getText().toString());
                int npsContributions = Integer.parseInt(npsContributionstext.getText().toString());
                int otherDeductions = Integer.parseInt(otherDeductionstext.getText().toString());

                TextView taxResultTextView = view.findViewById(R.id.res);
                TextView tax2ResultTextView = view.findViewById(R.id.res2);

                double taxLiabilityFY22 = calculateTaxLiabilityFY22(age, salary, sec80c, medInsurance, homeLoanInterest, eduLoanInterest, evLoanInterest, charityDonations, npsContributions, otherDeductions);
                double taxLiabilityFY23 = calculateTaxLiabilityFY23(salary, hra, lta, savingsDepositInterest, otherAllowances, npsContributions);

                String result1Text = String.format("Tax Liability as per Old Regime (FY22-23):  ₹%.2f", taxLiabilityFY22);
                String result2Text = String.format("Tax Liability as per New Regime (FY23-24):  ₹%.2f", taxLiabilityFY23);

                taxResultTextView.setText(result1Text);
                tax2ResultTextView.setText(result2Text);
            }
        });
    }


    private double calculateTaxLiabilityFY22(int age, int salary,
                                             int sec80c, int medInsurance, int homeLoanInterest, int eduLoanInterest,
                                             int evLoanInterest, int charityDonations, int npsContributions, int otherDeductions) {
        // Calculate total income (only salary considered)
        int totalIncome = salary;

        // Subtract standard deduction
        int standardDeduction = 50000;

        // Calculate taxable income
        int taxableIncome = totalIncome - standardDeduction;

        // Calculate total exemptions
        int totalExemptions = sec80c + medInsurance + homeLoanInterest + eduLoanInterest + evLoanInterest
                + charityDonations + npsContributions + otherDeductions;

        // Apply the exemption limit based on age
        int exemptionLimit = (age < 60) ? 250000 : 300000;
        totalExemptions = Math.min(totalExemptions, exemptionLimit);



        // Check if the income is at least 5 lakhs to apply exemptions
        if (totalIncome >= 500000) {
            taxableIncome -= totalExemptions;
        }

        // Calculate tax liability based on the tax slabs and age
        double taxLiability = 0;
        if (age < 60) {
            if (taxableIncome > 1000000) {
                taxLiability += (taxableIncome - 1000000) * 0.3;
                taxableIncome = 1000000;
            }

            if (taxableIncome > 500000) {
                taxLiability += (taxableIncome - 500000) * 0.2;
                taxableIncome = 500000;
            }

            if (taxableIncome > 250000) {
                taxLiability += (taxableIncome - 250000) * 0.1;
            }
        }
 else {
            if (taxableIncome > 1000000) {
                taxLiability += (taxableIncome - 1000000) * 0.3;
                taxableIncome = 1000000;
            }

            if (taxableIncome > 500000) {
                taxLiability += (taxableIncome - 500000) * 0.2;
                taxableIncome = 500000;
            }

            if (taxableIncome > 300000) {
                taxLiability += (taxableIncome - 300000) * 0.05;
            }
        }

        // Apply tax rebate under section 87A for individuals with net taxable income less than or equal to Rs 5 lakh
        if (taxLiability <= 12500 && totalIncome <= 500000) {
            taxLiability = 0;
        }


        return taxLiability;
    }


    private double calculateTaxLiabilityFY23(int salary, int hra, int lta, int savingsDepositInterest, int otherAllowances,
                                             int npsContributions) {
        // Calculate total income
        int totalIncome = salary + hra + lta + savingsDepositInterest + otherAllowances;

        // Calculate total exemptions
        int totalExemptions = npsContributions;

        // Apply the exemption limit
        int exemptionLimit = 250000;
        totalExemptions = Math.min(totalExemptions, exemptionLimit);

        // Calculate taxable income
        int taxableIncome = totalIncome;

        // Check if the income is at least 7 lakhs to apply exemptions
        if (totalIncome >= 700000) {
            taxableIncome -= totalExemptions;
        }

        // Calculate tax liability based on the tax slabs
        double taxLiability = 0;

        if (taxableIncome > 1500000) {
            taxLiability += (taxableIncome - 1500000) * 0.3;
            taxableIncome = 1500000;
        }

        if (taxableIncome > 1250000) {
            taxLiability += (taxableIncome - 1250000) * 0.2;
            taxableIncome = 1250000;
        }

        if (taxableIncome > 1200000) {
            taxLiability += (taxableIncome - 1200000) * 0.2;
            taxableIncome = 1200000;
        }

        if (taxableIncome > 1000000) {
            taxLiability += (taxableIncome - 1000000) * 0.15;
            taxableIncome = 1000000;
        }

        if (taxableIncome > 900000) {
            taxLiability += (taxableIncome - 900000) * 0.15;
            taxableIncome = 900000;
        }

        if (taxableIncome > 750000) {
            taxLiability += (taxableIncome - 750000) * 0.1;
            taxableIncome = 750000;
        }

        if (taxableIncome > 600000) {
            taxLiability += (taxableIncome - 600000) * 0.1;
            taxableIncome = 600000;
        }

        if (taxableIncome > 500000) {
            taxLiability += (taxableIncome - 500000) * 0.05;
            taxableIncome = 500000;
        }

        if (taxableIncome > 300000) {
            taxLiability += (taxableIncome - 300000) * 0.05;
            taxableIncome = 300000;
        }

        // Apply tax rebate under section 87A for individuals with net taxable income less than or equal to Rs 7 lakh
        if (taxLiability <= 15000 && totalIncome <= 700000) {
            taxLiability = 0;
        }


        return taxLiability;
    }

}






